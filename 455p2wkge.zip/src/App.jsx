
import { useState } from "react";
import Header from "./components/Header";
import ProductCard from "./components/ProductCard";
import Footer from "./components/Footer";
import "./App.css";

function App() {
  const [quantity, setQuantity] = useState(0);
  const [selectedColor, setSelectedColor] = useState("Black");
  const [deliveryCity, setDeliveryCity] = useState("Coimbatore");
  const [showProduct, setShowProduct] = useState(true);

  const productName = "Wireless Mouse";
  const price = 499;

  const totalAmount = quantity * price;

  const addToCart = () => {
    setQuantity((currentQuantity) => currentQuantity + 1);
  };

  const removeOne = () => {
    setQuantity((currentQuantity) =>
      Math.max(0, currentQuantity - 1)
    );
  };

  const resetCart = () => {
    setQuantity(0);
  };

  const toggleProduct = () => {
    setShowProduct((currentValue) => !currentValue);
  };

  return (
    <div className="app-shell">
      <Header />

      <main className="main-content">
        <div className="welcome-row">
          <div>
            <p className="eyebrow">YOUR SHOPPING SPACE</p>
            <h2 className="page-title">Product showcase</h2>
            <p className="page-subtitle">
              Discover your everyday essential.
            </p>
          </div>

          <div className="cart-indicator">
            <span className="cart-icon">🛒</span>
            <div>
              <span className="cart-indicator-label">YOUR CART</span>
              <strong>
                {quantity} {quantity === 1 ? "item" : "items"}
              </strong>
            </div>
          </div>
        </div>

        <div className="content-grid">
          <div className="main-column">
            {showProduct ? (
              <ProductCard
                productName={productName}
                price={price}
                quantity={quantity}
                selectedColor={selectedColor}
                deliveryCity={deliveryCity}
              />
            ) : (
              <section className="hidden-product">
                <div className="hidden-icon">◈</div>
                <h3>Your product is hidden</h3>
                <p>
                  Your cart and preferences are safe.
                  Show the product to continue shopping.
                </p>
                <button
                  className="btn btn-primary"
                  onClick={toggleProduct}
                >
                  Show Product
                </button>
              </section>
            )}

            <section className="controls-card">
              <div className="section-heading">
                <div>
                  <p className="eyebrow">PERSONALIZE</p>
                  <h3>Product preferences</h3>
                </div>
                <span className="step-badge">01</span>
              </div>

              <div className="form-grid">
                <div className="form-group">
                  <label htmlFor="productColor">
                    Product colour
                  </label>
                  <select
                    id="productColor"
                    value={selectedColor}
                    onChange={(event) =>
                      setSelectedColor(event.target.value)
                    }
                  >
                    <option value="Black">Black</option>
                    <option value="Blue">Blue</option>
                    <option value="White">White</option>
                  </select>
                </div>

                <div className="form-group">
                  <label htmlFor="deliveryCity">
                    Delivery city
                  </label>
                  <input
                    id="deliveryCity"
                    type="text"
                    placeholder="Enter your city"
                    value={deliveryCity}
                    onChange={(event) =>
                      setDeliveryCity(event.target.value)
                    }
                  />
                </div>
              </div>

              <div className="control-divider"></div>

              <div className="section-heading action-heading">
                <div>
                  <p className="eyebrow">CART MANAGEMENT</p>
                  <h3>Manage your cart</h3>
                </div>
                <span className="quantity-pill">
                  Qty: {quantity}
                </span>
              </div>

              <div className="button-grid">
                <button
                  className="btn btn-primary"
                  onClick={addToCart}
                >
                  <span>＋</span> Add to Cart
                </button>

                <button
                  className="btn btn-secondary"
                  onClick={removeOne}
                  disabled={quantity === 0}
                >
                  <span>−</span> Remove One
                </button>

                <button
                  className="btn btn-secondary"
                  onClick={resetCart}
                >
                  ↻ Reset Cart
                </button>

                <button
                  className="btn btn-outline"
                  onClick={toggleProduct}
                >
                  {showProduct ? "Hide Product" : "Show Product"}
                </button>
              </div>

              <p className="helper-text">
                <span>ⓘ</span> Resetting the cart changes only
                the quantity. Your preferences stay saved.
              </p>
            </section>
          </div>

          <aside className="sidebar">
            <section className="benefits-card">
              <div className="benefits-top">
                <span className="benefits-icon">✦</span>
                <div>
                  <p className="eyebrow">THE STORE PROMISE</p>
                  <h3>Shopping made simple</h3>
                </div>
              </div>

              <div className="benefit-item">
                <span className="benefit-icon">✓</span>
                <div>
                  <strong>Quality essentials</strong>
                  <p>Made for everyday productivity.</p>
                </div>
              </div>

              <div className="benefit-item">
                <span className="benefit-icon">⌖</span>
                <div>
                  <strong>City-based delivery</strong>
                  <p>Personalize your delivery location.</p>
                </div>
              </div>

              <div className="benefit-item">
                <span className="benefit-icon">₹</span>
                <div>
                  <strong>Transparent pricing</strong>
                  <p>One price for every colour.</p>
                </div>
              </div>
            </section>

            <section className="order-card">
              <p className="eyebrow">ORDER SUMMARY</p>
              <h3>Your total</h3>

              <div className="order-line">
                <span>Wireless Mouse</span>
                <span>₹{price}</span>
              </div>

              <div className="order-line">
                <span>Quantity</span>
                <span>× {quantity}</span>
              </div>

              <div className="order-divider"></div>

              <div className="order-total">
                <span>Total</span>
                <strong>
                  ₹{totalAmount.toLocaleString("en-IN")}
                </strong>
              </div>

              <p className="order-note">
                Sample cart total · No payment required
              </p>
            </section>

            <div className="learning-note">
              <span className="learning-icon">⚛</span>
              <div>
                <strong>Built with React</strong>
                <p>Components · Props · State · Hooks</p>
              </div>
            </div>
          </aside>
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default App;
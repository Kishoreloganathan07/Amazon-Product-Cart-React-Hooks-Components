
function Header() {
  return (
    <header className="store-header">
      <div className="header-inner">
        <div className="brand">
          <span className="brand-mark">a</span>
          <div>
            <h1>Amazon Product Store</h1>
            <p>Everything you need, delivered with care.</p>
          </div>
        </div>

        <div className="header-tag">
          <span className="status-dot"></span>
          Demo Store
        </div>
      </div>
    </header>
  );
}

export default Header;
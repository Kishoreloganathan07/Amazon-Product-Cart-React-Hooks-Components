
function Footer() {
  return (
    <footer className="store-footer">
      <div className="footer-brand">
        <span className="footer-mark">a</span>
        <span>Amazon Product Store</span>
      </div>

      <p>Simple shopping. Smarter experience.</p>

      <div className="footer-divider"></div>

      <small>© 2026 Amazon Product Store</small>
    </footer>
  );
}

export default Footer;
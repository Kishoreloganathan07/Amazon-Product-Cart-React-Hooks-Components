
import { useEffect } from "react";

function ProductCard({
  productName,
  price,
  quantity,
  selectedColor,
  deliveryCity,
}) {
  useEffect(() => {
    const previousTitle = document.title;

    document.title =
      `${productName} | ${selectedColor} | Cart: ${quantity}`;

    return () => {
      document.title = previousTitle;
    };
  }, [productName, selectedColor, quantity]);

  const totalAmount = quantity * price;

  const colorClass = selectedColor.toLowerCase();

  return (
    <section className="product-card">
      <div className="product-visual">
        <div className={`mouse mouse-${colorClass}`}>
          <div className="mouse-wheel"></div>
          <div className="mouse-line"></div>
        </div>
        <span className="image-caption">WIRELESS · ERGONOMIC</span>
      </div>

      <div className="product-info">
        <div className="product-label">
          <span className="tiny-dot"></span>
          FEATURED PRODUCT
        </div>

        <h2>{productName}</h2>

        <div className="price-row">
          <span className="price-symbol">₹</span>
          <span className="price">{price}</span>
          <span className="per-item">per item</span>
        </div>

        <div className="product-details">
          <div className="detail-row">
            <span className="detail-icon">◉</span>
            <span>Colour</span>
            <strong>{selectedColor}</strong>
            <span className={`color-swatch swatch-${colorClass}`}></span>
          </div>

          <div className="detail-row">
            <span className="detail-icon">⌖</span>
            <span>Deliver to</span>
            <strong>{deliveryCity || "Enter your city"}</strong>
          </div>
        </div>

        <div className="cart-summary">
          <div>
            <span className="summary-label">CART QUANTITY</span>
            <strong className="quantity-value">{quantity}</strong>
          </div>

          <div className="summary-total">
            <span className="summary-label">TOTAL AMOUNT</span>
            <strong>₹{totalAmount.toLocaleString("en-IN")}</strong>
          </div>
        </div>

        <div className={`cart-status ${quantity > 0 ? "in-cart" : ""}`}>
          <span className="status-check">
            {quantity > 0 ? "✓" : "i"}
          </span>
          {quantity === 0
            ? "Cart is empty"
            : "Product added to cart"}
        </div>
      </div>
    </section>
  );
}

export default ProductCard;
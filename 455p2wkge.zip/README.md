# Amazon Product Cart

## Project Overview

A responsive Amazon-style product cart built with React. This project demonstrates components, JSX, props, state management, controlled inputs, conditional rendering, and lifecycle behaviour using React Hooks.

## Features

* Header, ProductCard, and Footer components
* Wireless Mouse priced at ₹499
* Black, Blue, and White colour options
* Controlled delivery city input
* Add to Cart, Remove One, Reset Cart, and Show/Hide Product
* Dynamic cart quantity and total calculation
* Browser tab title updates using `useEffect`
* Effect cleanup restores the previous document title
* Responsive interface with custom CSS styling

## Technologies

* React
* JavaScript
* JSX
* CSS
* React Hooks: `useState` and `useEffect`

## Installation and Execution

1. Open the project folder in the terminal.
2. Install dependencies using `npm install`.
3. Start the development server using `npm run dev`.
4. Open the local URL shown in the terminal.

## Testing

| Test                       | Expected Result                            |
| -------------------------- | ------------------------------------------ |
| Initial load               | Quantity 0; total ₹0                       |
| Add twice                  | Quantity 2; total ₹998                     |
| Change colour              | Selected colour and tab title update       |
| Change city                | Delivery city updates immediately          |
| Remove one from quantity 2 | Quantity 1; total ₹499                     |
| Hide and show              | Product disappears and saved state returns |
| Reset cart                 | Quantity 0; total ₹0                       |
| Remove at zero             | Button disabled                            |

## Notes

This is a demonstration cart. It does not process payments or connect to a real Amazon service.
